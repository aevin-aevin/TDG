"""Supplementary Code 1. Main analysis: stratum profiles, model comparison, leave-one-stratum-out validation, bootstrap bends.
Usage: MINN=1000 python Supplementary_Code_1_tdg_all.py by_gene.txt outdir 300
  by_gene.txt: tab-separated Gene, NCBid, phyl17 (1-17) and the by-gene parameters (Supplementary Data 1, sheet by_gene)
  outdir: output folder (must exist); last argument = number of bootstrap replicates (the manuscript used 300)
Requires numpy and pandas.
"""
import sys, itertools, json, numpy as np, pandas as pd
np.seterr(all='ignore')
src, out, B = sys.argv[1], sys.argv[2], int(sys.argv[3])
df = pd.read_csv(src, sep='\t'); df = df[df.phyl17.between(1,17)]
rng = np.random.default_rng(1)
X = np.arange(1,18.)
META = {'Gene','NCBid','phyl17'}
layers = {}
for c in df.columns:
    if c in META: continue
    v = pd.to_numeric(df[c], errors='coerce')
    if v.notna().sum()<int(__import__("os").environ.get("MINN","1000")): continue
    kind = 'binom' if set(v.dropna().unique()) <= {0,1} else 'gauss'
    layers[c] = kind
print(layers)
def stats(c, d):
    k = layers[c]; g = d.groupby('phyl17')[c]
    n = g.count().reindex(range(1,18)).values.astype(float)
    m = g.mean().reindex(range(1,18)).values
    if k=='gauss':
        s = g.var().reindex(range(1,18)).values
        var = s/n
    else:
        p = (m*n+.5)/(n+1); var = p*(1-p)/n
    return n, m, var
def wls(Xd, y, w):
    A = Xd*np.sqrt(w)[:,None]; b = y*np.sqrt(w)
    beta = np.linalg.lstsq(A,b,rcond=None)[0]
    r = y-Xd@beta
    return beta, np.sum(w*r*r), Xd@beta
def design_poly(deg): return np.vander(X-9, deg+1, increasing=True)
def design_hinge(ks):
    cols=[np.ones(17), X]+[np.maximum(0,X-k) for k in ks]
    return np.column_stack(cols)
KG = np.arange(1.5,16.6,0.5)
PAIRS = [(a,b) for a in KG for b in KG if b-a>=1.0]
def best_hinge(y,w,nk=2):
    best=None
    sets = [(k,) for k in KG] if nk==1 else PAIRS
    for ks in sets:
        beta,chi,fit = wls(design_hinge(ks),y,w)
        if best is None or chi<best[0]: best=(chi,ks,fit)
    return best
def seg_design(b1,b2):  # step model, segments 1..b1, b1+1..b2, b2+1..17
    D=np.zeros((17,3)); D[:b1,0]=1; D[b1:b2,1]=1; D[b2:,2]=1; return D
PARTS=[(a,b) for a in range(1,16) for b in range(a+1,17)]
def apr(): return (4,9)   # CMG PS1-4, MAG PS5-9, PVG PS10-17
def tss(y,w):
    mu=np.sum(w*y)/np.sum(w); return np.sum(w*(y-mu)**2)
rows=[]; loso=[]; rank=[]; prof=[]; fits={}
for c in layers:
    n,m,var = stats(c, df); ok=~np.isnan(m)&(var>0)
    if ok.sum()<14: print('skip',c); continue
    idx=np.where(ok)[0]
    y=np.where(ok,m,0); w=np.where(ok,1/np.where(var>0,var,1),0)
    ww = np.where(ok, n, 0)  # n-weights for R2 across genes-level
    sd = np.sqrt(np.sum(ww*(y-np.sum(ww*y)/ww.sum())**2)/ww.sum())
    ys=y/sd
    # work on standardized scale; chi2 uses var/sd^2
    wz = w*sd**2
    T = tss(ys,ww/ww.sum())  # n-weighted variance between strata (=1 share)
    mods={}
    def rec(name,p,fit,chi): mods[name]=dict(p=p,fit=fit,chi=chi)
    for nm,Xd in [('constant',np.ones((17,1))),('linear',design_poly(1)),('quadratic',design_poly(2)),('cubic',design_poly(3))]:
        beta,chi,fit=wls(Xd[ok],ys[ok],wz[ok]); f=np.full(17,np.nan); f[ok]=fit; rec(nm,Xd.shape[1],f,chi)
    for nk in (1,2):
        # restrict to ok strata
        best=None
        sets=[(k,) for k in KG] if nk==1 else PAIRS
        for ks in sets:
            Xd=design_hinge(ks)[ok]; beta,chi,fit=wls(Xd,ys[ok],wz[ok])
            if best is None or chi<best[0]: best=(chi,ks,fit)
        f=np.full(17,np.nan); f[ok]=best[2]; rec(f'hinge{nk}',2+2*nk,f,best[0]); mods[f'hinge{nk}']['ks']=best[1]
    # best 3-seg step
    best=None; allp=[]
    for pt in PARTS:
        Xd=seg_design(*pt)[ok]
        if (Xd.sum(0)==0).any(): continue
        beta,chi,fit=wls(Xd,ys[ok],wz[ok]); allp.append((chi,pt))
        if best is None or chi<best[0]: best=(chi,pt,fit)
    f=np.full(17,np.nan); f[ok]=best[2]; rec('step3_best',5,f,best[0]); mods['step3_best']['pt']=best[1]
    Xd=seg_design(*apr())[ok]; beta,chi,fit=wls(Xd,ys[ok],wz[ok]); f=np.full(17,np.nan); f[ok]=fit; rec('step3_apriori',3,f,chi)
    allp.sort(); rk=[i for i,(ch,pt) in enumerate(allp,1) if pt==apr()][0]
    rank.append(dict(layer=c,rank_of_apriori=rk,n_partitions=len(allp),best_partition=str(allp[0][1])))
    # R2 between strata (n-weighted)
    for nm,d in mods.items():
        r=ys-d['fit']; sse=np.nansum(ww*r*r)/ww.sum(); d['R2']=1-sse/T
        rows.append(dict(layer=c,kind=layers[c],model=nm,params=d['p'],chi2=d['chi'],AIC=d['chi']+2*d['p'],R2_between=d['R2'],
                         bends=str(d.get('ks',d.get('pt','')))))
    # LOSO (leave one stratum out) with refit, report n-weighted RMSE share
    names=['constant','linear','quadratic','cubic','hinge2','step3_apriori']
    err={k:0. for k in names}
    for leave in idx:
        keep=ok.copy(); keep[leave]=False
        for nm in names:
            if nm in('constant','linear','quadratic','cubic'):
                deg={'constant':0,'linear':1,'quadratic':2,'cubic':3}[nm]; Xd=design_poly(deg)
                beta,_,_=wls(Xd[keep],ys[keep],wz[keep]); pr=Xd[leave]@beta
            elif nm=='hinge2':
                bb=None
                for ks in PAIRS:
                    Xd=design_hinge(ks); beta,chi,_=wls(Xd[keep],ys[keep],wz[keep])
                    if bb is None or chi<bb[0]: bb=(chi,ks,beta)
                pr=design_hinge(bb[1])[leave]@bb[2]
            else:
                Xd=seg_design(*apr())
                if Xd[keep].sum(0).min()==0: pr=np.nan
                else:
                    beta,_,_=wls(Xd[keep],ys[keep],wz[keep]); pr=Xd[leave]@beta
            err[nm]+=ww[leave]*(ys[leave]-pr)**2
    tot=ww.sum()
    loso.append(dict(layer=c,**{k:1-err[k]/tot/T for k in names}))
    prof.append(pd.DataFrame(dict(layer=c,PS=range(1,18),n=n,mean=m,z=ys,fit_hinge2=mods['hinge2']['fit'],fit_step=mods['step3_apriori']['fit'],fit_quad=mods['quadratic']['fit'])))
    fits[c]=dict(ys=ys,wz=wz,ok=ok,ww=ww,T=T)
M=pd.DataFrame(rows); L=pd.DataFrame(loso); R=pd.DataFrame(rank); P=pd.concat(prof)
M.to_csv(out+'/models.csv',index=False); L.to_csv(out+'/loso.csv',index=False); R.to_csv(out+'/rank.csv',index=False); P.to_csv(out+'/profiles.csv',index=False)
# shared-bend, molecular/all gauss layers: fraction of between-strata variance unexplained
def shared(cs):
    best=None; tab=[]
    for ks in PAIRS:
        tot=0
        for c in cs:
            f=fits[c]; ok=f['ok']; Xd=design_hinge(ks)[ok]; beta,_,fit=wls(Xd,f['ys'][ok],f['wz'][ok])
            r=f['ys'][ok]-fit; tot+=np.sum(f['ww'][ok]*r*r)/f['ww'].sum()/f['T']
        tab.append((tot/len(cs),ks))
    tab.sort(); return tab
res={}
groups={'all_gauss':[c for c in fits if layers[c]=='gauss'],
        'molecular5':[c for c in ['mRNA','protein','mRNA_prot_ratio','5UTR_size_lg10','Chromatin_accessibility'] if c in fits],
        'methylation':[c for c in fits if 'methylation' in c]}
for g,cs in groups.items():
    if not cs: continue
    tab=shared(cs)
    # a-priori knots (4.5,9.5) i.e. between PS4/5 and 9/10
    ap=[t for t in tab if t[1]==(4.5,9.5)][0]; ap2=[t for t in tab if t[1]==(4.5,9.0)][0]
    sep=np.mean([1-M[(M.layer==c)&(M.model=='hinge2')].R2_between.values[0] for c in cs])
    res[g]=dict(layers=cs,best=tab[:5],apriori_unexpl=ap[0],apriori_rank=tab.index(ap)+1,apriori2_unexpl=ap2[0],apriori2_rank=tab.index(ap2)+1,of=len(tab),separate_unexpl=sep)
json.dump(res,open(out+'/shared.json','w'),indent=1,default=float)
# bootstrap bends (hinge2) per layer
bs=[]
G={k:v for k,v in df.groupby('phyl17')}
for b in range(B):
    d=pd.concat([g.sample(len(g),replace=True,random_state=int(rng.integers(1e9))) for g in G.values()])
    for c in layers:
        if c not in fits: continue
        n,m,var=stats(c,d); ok=~np.isnan(m)&(var>0)
        if ok.sum()<14: continue
        y=np.where(ok,m,0); sd=np.sqrt(np.sum(n[ok]*(y[ok]-np.sum(n[ok]*y[ok])/n[ok].sum())**2)/n[ok].sum())
        w=np.where(ok,1/np.where(var>0,var,1),0)*sd**2; ys=y/sd
        best=None
        for ks in PAIRS:
            _,chi,_=wls(design_hinge(ks)[ok],ys[ok],w[ok])
            if best is None or chi<best[0]: best=(chi,ks)
        bs.append(dict(b=b,layer=c,k1=best[1][0],k2=best[1][1]))
BS=pd.DataFrame(bs); BS.to_csv(out+'/bootstrap.csv',index=False)
print(BS.groupby('layer')[['k1','k2']].agg(['median',lambda s:s.quantile(.025),lambda s:s.quantile(.975)]))
print(R.to_string()); print(L.round(2).to_string()); print(json.dumps(res,indent=1,default=float))
